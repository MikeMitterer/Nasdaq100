ActionBarSherlock Sample: Known Bugs
====================================

This sample demonstrates the known bugs at the time of release. By having this
included and revisioned with the library we allow for easier verification of
regressions and fixes.

If you want to submit a new bug to the library it would be extremely helpful
if you filed a separate pull request which adds a test case. Doing so will
ensure we can reproduce your bug properly and ensure that a proper fix gets
implemented.